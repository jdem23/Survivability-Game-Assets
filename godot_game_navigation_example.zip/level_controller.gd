extends Node2D

# Universal Level Controller:
# Demonstrates how any level navigates forward to the next scene or back to the menu.

@export_file("*.tscn") var next_level_scene: String = ""
@export var level_name: String = "Level"

func _ready() -> void:
	$CanvasLayer/LevelHeader.text = level_name
	
	$CanvasLayer/NavPanel/HBox/BtnMenu.pressed.connect(_on_menu_pressed)
	$CanvasLayer/NavPanel/HBox/BtnRestart.pressed.connect(_on_restart_pressed)
	$CanvasLayer/NavPanel/HBox/BtnNext.pressed.connect(_on_next_pressed)

	# If there is no next level (final level), change button text to 'Finish Game'
	if next_level_scene == "":
		$CanvasLayer/NavPanel/HBox/BtnNext.text = "Complete Game! ->"

func _on_next_pressed() -> void:
	if next_level_scene != "":
		# Navigate to the next level scene file
		get_tree().change_scene_to_file(next_level_scene)
	else:
		# If completed the final level, go to victory screen
		get_tree().change_scene_to_file("res://victory_screen.tscn")

func _on_restart_pressed() -> void:
	# Reload current scene
	get_tree().reload_current_scene()

func _on_menu_pressed() -> void:
	# Return to Level Selection Menu
	get_tree().change_scene_to_file("res://main_menu.tscn")
