extends Control

# Main Menu: Allows the player to jump to any level or quit the game.

func _ready() -> void:
	$CenterContainer/VBoxContainer/BtnLevel1.pressed.connect(func(): _load_level("res://level_1.tscn"))
	$CenterContainer/VBoxContainer/BtnLevel2.pressed.connect(func(): _load_level("res://level_2.tscn"))
	$CenterContainer/VBoxContainer/BtnLevel3.pressed.connect(func(): _load_level("res://level_3.tscn"))
	$CenterContainer/VBoxContainer/BtnTitle.pressed.connect(func(): get_tree().change_scene_to_file("res://title_screen.tscn"))

func _load_level(path: String) -> void:
	get_tree().change_scene_to_file(path)
