# Godot Game Structure & Scene Navigation Template

This project demonstrates how to structure and navigate a complete multi-scene game in Godot 4 without complex code.

### Game Flow Architecture:
1. **`title_screen.tscn`**:
   - The entry point (`run/main_scene`).
   - Displays game title and waits for "Press Start" (click or space bar).
   - Transitions to: `main_menu.tscn`.

2. **`main_menu.tscn`**:
   - The level selection menu.
   - Buttons to jump directly to Level 1, Level 2, or Level 3, or return to Title.

3. **`level_1.tscn` -> `level_2.tscn` -> `level_3.tscn`**:
   - Uses a single universal script (`level_controller.gd`) with `@export_file("*.tscn") var next_level_scene`.
   - Each level has on-screen controls to:
     - **Advance**: `get_tree().change_scene_to_file(next_level_scene)`
     - **Restart**: `get_tree().reload_current_scene()`
     - **Exit**: `get_tree().change_scene_to_file("res://main_menu.tscn")`

4. **`victory_screen.tscn`**:
   - Reached upon completing Level 3.
   - Allows replaying from Level 1, jumping to the menu, or returning to the title.

### The Key Godot Function:
```gdscript
get_tree().change_scene_to_file("res://path_to_scene.tscn")
```
When this runs, Godot unloads the current active scene from memory and replaces it with the new one.
