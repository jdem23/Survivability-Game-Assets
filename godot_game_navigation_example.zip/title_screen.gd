extends Control

# Title Screen: The first scene the player sees.
# Simply waits for a click or key press to advance to the Main Menu.

func _ready() -> void:
	$VBoxContainer/BtnStart.pressed.connect(_go_to_menu)

func _unhandled_input(event: InputEvent) -> void:
	# Also allow pressing Space or Enter to continue
	if event.is_action_pressed("ui_accept"):
		_go_to_menu()

func _go_to_menu() -> void:
	# Change from Title Screen to Main Menu
	get_tree().change_scene_to_file("res://main_menu.tscn")
