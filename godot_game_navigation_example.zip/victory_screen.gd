extends Control

func _ready() -> void:
	$CenterContainer/VBoxContainer/BtnPlayAgain.pressed.connect(func(): get_tree().change_scene_to_file("res://level_1.tscn"))
	$CenterContainer/VBoxContainer/BtnMenu.pressed.connect(func(): get_tree().change_scene_to_file("res://main_menu.tscn"))
	$CenterContainer/VBoxContainer/BtnTitle.pressed.connect(func(): get_tree().change_scene_to_file("res://title_screen.tscn"))
