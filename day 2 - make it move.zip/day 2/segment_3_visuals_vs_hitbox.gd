extends Node2D

# SEGMENT 3: Physics 101 — Visuals vs. Physical Reality
# Instructor note: Enable 'Debug > Visible Collision Shapes' to see hitboxes at runtime.
# Game engines do not calculate collisions from sprites/textures; they calculate math
# strictly on invisible CollisionShape2D boundaries (as highlighted by Masahiro Sakurai).

@onready var player: CharacterBody2D = $Player
var push_speed: float = 250.0

func _physics_process(_delta: float) -> void:
	# Move player toward the right wall to demonstrate collision boundary
	var direction = Input.get_axis("ui_left", "ui_right")
	if direction == 0.0:
		direction = 1.0 # Auto-drift right for demonstration
	player.velocity.x = direction * push_speed
	player.move_and_slide()
