extends Node2D

# SEGMENT 2: Basic Movement & Emulated Touch
# Requires: Project Settings > Input Devices > Pointing > Emulate Touch From Mouse = True
# Why? Desktop arrow keys (Input.is_action_pressed) don't exist on phone screens.

@export var move_speed: float = 400.0
@export var smooth_movement: bool = true # Toggle between teleport and smooth slide

@onready var character: ColorRect = $Character
var target_pos: Vector2

func _ready() -> void:
	target_pos = character.position

func _unhandled_input(event: InputEvent) -> void:
	# Detect touch down or drag (simulated by mouse clicks/drags in editor)
	if event is InputEventScreenTouch and event.pressed:
		target_pos = event.position - (character.size / 2.0)
	elif event is InputEventScreenDrag:
		target_pos = event.position - (character.size / 2.0)

func _process(delta: float) -> void:
	if smooth_movement:
		# SMOOTH SLIDE: Glides toward touch point at constant speed using delta
		character.position = character.position.move_toward(target_pos, move_speed * delta)
	else:
		# INSTANT TELEPORT: Jumps immediately to touch point (feels jarring & skips obstacles)
		character.position = target_pos
