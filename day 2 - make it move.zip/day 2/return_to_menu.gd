extends Button

# Returns to the title screen when clicked
func _ready() -> void:
	pressed.connect(_on_pressed)

func _on_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
