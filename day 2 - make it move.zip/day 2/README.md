# Godot 4 2D Lesson Starter Project (with Title Menu)

This starter project includes a Title Menu scene and four self-contained demo scenes:

- **`main_menu.tscn`**: Default startup scene with interactive buttons to launch any segment.
- **`segment_1_gameloop.tscn`**: Game Loop & Delta Time comparison.
- **`segment_2_touch_movement.tscn`**: Emulated touch / smooth slide movement.
- **`segment_3_visuals_vs_hitbox.tscn`**: Visual sprites vs CollisionShape2D physics.
- **`segment_4_team_lab.tscn`**: Gravity, CharacterBody2D, and StaticBody2D landing floor.

Every segment scene includes a **"<- Back to Menu"** button so you can freely navigate between demos!

### Quick Start:
1. Extract and open the project in Godot 4.
2. Press **F5** (Play Project) to launch directly into the Title Menu.
3. Click any segment button to test that lesson's demo.
