extends CharacterBody2D

# SEGMENT 4: Team Lab — Programmer Objective
# - Gravity in _physics_process
# - Jump via Space Bar
# - Left/Right movement & landing on floor

@export var speed: float = 250.0
@export var gravity: float = 980.0
@export var jump_velocity: float = -480.0

func _ready() -> void:
	# Ensure Space bar is explicitly mapped to 'jump' action
	if not InputMap.has_action("jump"):
		InputMap.add_action("jump")
		var ev = InputEventKey.new()
		ev.physical_keycode = KEY_SPACE
		InputMap.action_add_event("jump", ev)

func _physics_process(delta: float) -> void:
	# 1. Apply gravity when in the air
	if not is_on_floor():
		velocity.y += gravity * delta

	# 2. Jump with Space Bar (only allowed when touching the floor)
	if is_on_floor() and (Input.is_action_just_pressed("jump") or Input.is_action_just_pressed("ui_accept")):
		velocity.y = jump_velocity

	# 3. Horizontal movement (Arrow keys or A/D)
	var direction = Input.get_axis("ui_left", "ui_right")
	if direction != 0.0:
		velocity.x = direction * speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed)

	# 4. Resolve physics collisions with floors and walls
	move_and_slide()
