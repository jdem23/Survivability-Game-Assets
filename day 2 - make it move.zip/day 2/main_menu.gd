extends Control

# Title Screen & Scene Selection Menu

func _ready() -> void:
	$VBoxContainer/BtnSegment1.pressed.connect(_on_btn_segment_1_pressed)
	$VBoxContainer/BtnSegment2.pressed.connect(_on_btn_segment_2_pressed)
	$VBoxContainer/BtnSegment3.pressed.connect(_on_btn_segment_3_pressed)
	$VBoxContainer/BtnSegment4.pressed.connect(_on_btn_segment_4_pressed)

func _on_btn_segment_1_pressed() -> void:
	get_tree().change_scene_to_file("res://segment_1_gameloop.tscn")

func _on_btn_segment_2_pressed() -> void:
	get_tree().change_scene_to_file("res://segment_2_touch_movement.tscn")

func _on_btn_segment_3_pressed() -> void:
	get_tree().change_scene_to_file("res://segment_3_visuals_vs_hitbox.tscn")

func _on_btn_segment_4_pressed() -> void:
	get_tree().change_scene_to_file("res://segment_4_team_lab.tscn")
