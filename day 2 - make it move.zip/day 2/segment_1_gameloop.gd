extends Node2D

# SEGMENT 1: Code and the Game Loop & Delta Time
# Flowchart connection: Input -> Update -> Render
# - Godot calls _process(delta) every rendered frame (Update phase).
# - 'delta' is the elapsed time in seconds since the previous frame.

@export var speed: float = 300.0 # Pixels per second

@onready var character_with_delta: ColorRect = $CharacterWithDelta
@onready var character_no_delta: ColorRect = $CharacterNoDelta

func _process(delta: float) -> void:
	# --- WITH DELTA (Frame-rate independent) ---
	# Multiplying by delta converts movement from 'pixels per frame' to 'pixels per second'.
	# 300 pixels/sec * 0.0166s (60 FPS) = ~5 pixels this frame.
	# 300 pixels/sec * 0.0500s (20 FPS) = ~15 pixels this frame.
	# Result: Both devices cover the exact same distance in 1 real-world second!
	character_with_delta.position.x += speed * delta
	
	# Wrap around the screen when reaching the edge
	if character_with_delta.position.x > get_viewport_rect().size.x:
		character_with_delta.position.x = 0.0
		
	# --- WITHOUT DELTA (Frame-rate dependent flaw) ---
	# Moving 5 pixels EVERY frame:
	# At 60 FPS: 5 * 60 = 300 pixels/second.
	# At 20 FPS (laggy phone): 5 * 20 = 100 pixels/second (runs 3x slower!).
	character_no_delta.position.x += 5.0
	if character_no_delta.position.x > get_viewport_rect().size.x:
		character_no_delta.position.x = 0.0
