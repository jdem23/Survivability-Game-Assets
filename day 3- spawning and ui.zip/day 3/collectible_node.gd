extends Area2D

@export var is_orphan_demonstration: bool = false
var lifetime: float = 0.0

func _ready() -> void:
	# BORN: Entered the scene tree
	$Label.text = "Node #%d" % get_instance_id()

func _process(delta: float) -> void:
	# LIVING: Updates position or animation every frame
	lifetime += delta
	# Subtle floating bob
	position.y += sin(lifetime * 4.0) * 0.5

# Safe destruction method
func destroy_properly() -> void:
	# DYING: queue_free() safely removes node at the end of the current frame
	queue_free()
