extends Area2D

# STEP 1: Define custom signal for the Observer Pattern
signal coin_collected(point_value: int)

@export var points: int = 100

@onready var coin_btn: Button = $CoinButton

var collected: bool = false

func _ready() -> void:
	# Primary: Click / Tap via Button pressed signal
	coin_btn.pressed.connect(collect)
	# Secondary: Walk-into collection via Area2D physics
	body_entered.connect(_on_body_entered)

func _on_body_entered(_body: Node2D) -> void:
	collect()

func collect() -> void:
	if collected:
		return
	collected = true
	# STEP 2: Emit signal to notify any listening systems (HUD)
	coin_collected.emit(points)
	# STEP 3: Safe destruction
	queue_free()
