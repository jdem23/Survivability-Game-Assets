extends Node2D

const COIN_SCENE = preload("res://collectible_coin.tscn")

@onready var score_label: Label = $HUD/ScorePanel/VBox/ScoreLabel
@onready var coin_container: Node2D = $CoinContainer
@onready var action_button: Button = $HUD/BottomRight/ActionTouchButton
@onready var player: CharacterBody2D = $Player
@onready var feedback_label: Label = $HUD/FeedbackLabel

var score: int = 0

func _ready() -> void:
	action_button.pressed.connect(_on_action_button_pressed)
	$HUD/ResetButton.pressed.connect(spawn_field_of_coins)
	spawn_field_of_coins()

func spawn_field_of_coins() -> void:
	for child in coin_container.get_children():
		child.queue_free()

	for i in range(6):
		var coin = COIN_SCENE.instantiate()
		coin.position = Vector2(300.0 + (i * 105.0), 300.0 + (sin(i * 1.3) * 70.0))
		# CONNECT OBSERVER SIGNAL:
		coin.coin_collected.connect(_on_coin_collected)
		coin_container.add_child(coin)

	feedback_label.text = "Spawned 6 gold coins! Click them or walk into them."

func _on_coin_collected(point_value: int) -> void:
	score += point_value
	# String conversion for UI display
	score_label.text = "Score: " + str(score)
	feedback_label.text = "Signal Received! Added %d points." % point_value

func _on_action_button_pressed() -> void:
	_on_coin_collected(50)
	feedback_label.text = "Mobile Touch Button Pressed! Added +50 via Signal."

func _physics_process(delta: float) -> void:
	# Optional character movement
	var dir = Input.get_axis("ui_left", "ui_right")
	if dir != 0.0:
		player.velocity.x = dir * 250.0
	else:
		player.velocity.x = move_toward(player.velocity.x, 0.0, 250.0)

	var dir_y = Input.get_axis("ui_up", "ui_down")
	if dir_y != 0.0:
		player.velocity.y = dir_y * 250.0
	else:
		player.velocity.y = move_toward(player.velocity.y, 0.0, 250.0)

	player.move_and_slide()
