extends Control

func _ready() -> void:
	$VBoxContainer/BtnTopic1.pressed.connect(_on_btn_topic_1_pressed)
	$VBoxContainer/BtnTopic2.pressed.connect(_on_btn_topic_2_pressed)
	$VBoxContainer/BtnTopic3.pressed.connect(_on_btn_topic_3_pressed)
	$VBoxContainer/BtnTopic4.pressed.connect(_on_btn_topic_4_pressed)

func _on_btn_topic_1_pressed() -> void:
	get_tree().change_scene_to_file("res://day3_seg1_instancing.tscn")

func _on_btn_topic_2_pressed() -> void:
	get_tree().change_scene_to_file("res://day3_seg2_lifecycle_memory.tscn")

func _on_btn_topic_3_pressed() -> void:
	get_tree().change_scene_to_file("res://day3_seg3_canvas_anchors.tscn")

func _on_btn_topic_4_pressed() -> void:
	get_tree().change_scene_to_file("res://day3_seg4_signals_hud.tscn")
