extends Node2D

# STEP 1: preload() - Loads the PackedScene from disk into RAM when the script compiles
const CRATE_SCENE = preload("res://crate.tscn")

@onready var spawn_container: Node2D = $SpawnContainer
@onready var count_label: Label = $UILayer/Panel/VBox/CountLabel

var spawned_count: int = 0

func _ready() -> void:
	$UILayer/Panel/VBox/BtnSpawnGrid.pressed.connect(spawn_grid)
	$UILayer/Panel/VBox/BtnClear.pressed.connect(clear_all)

func _unhandled_input(event: InputEvent) -> void:
	# Click or tap anywhere in the world to spawn a prefab instance
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		spawn_at(event.position)
	elif event is InputEventScreenTouch and event.pressed:
		spawn_at(event.position)

func spawn_at(target_position: Vector2) -> void:
	# Ignore clicks on the control panel
	if target_position.x < 320 and target_position.y < 350:
		return

	# STEP 2: instantiate() - Creates a fresh, living clone of the PackedScene
	var new_crate = CRATE_SCENE.instantiate()

	# POSITIONING: Configure where it lives BEFORE or right after injecting into the world
	new_crate.position = target_position

	# STEP 3: add_child() - Injects the clone into the Scene Tree so it renders & ticks
	spawn_container.add_child(new_crate)

	spawned_count += 1
	update_ui()

func spawn_grid() -> void:
	# Demonstrates why hand-placing 50 objects in the editor is a nightmare!
	clear_all()
	var start_x = 380.0
	var start_y = 150.0
	var spacing = 60.0

	for row in range(5):
		for col in range(8):
			# 3-step pipeline inside a loop:
			var crate = CRATE_SCENE.instantiate()
			crate.position = Vector2(start_x + (col * spacing), start_y + (row * spacing))
			spawn_container.add_child(crate)
			spawned_count += 1

	update_ui()

func clear_all() -> void:
	for child in spawn_container.get_children():
		child.queue_free()
	spawned_count = 0
	update_ui()

func update_ui() -> void:
	count_label.text = "Instances in Scene: %d" % spawned_count
