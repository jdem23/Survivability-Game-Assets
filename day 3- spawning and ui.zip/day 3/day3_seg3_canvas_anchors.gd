extends Node2D

@onready var world_camera: Camera2D = $World/Camera2D
@onready var pan_slider: HSlider = $CanvasLayer/ControlsPanel/VBox/PanSlider
@onready var player: CharacterBody2D = $World/Player
@onready var hp_label: Label = $CanvasLayer/TopLeftAnchored/Margin/Label
@onready var score_label: Label = $CanvasLayer/TopRightAnchored/Margin/Label
@onready var feedback_label: Label = $CanvasLayer/FeedbackLabel

var move_direction: float = 0.0
var hp: int = 100
var score: int = 12450

func _ready() -> void:
	pan_slider.value_changed.connect(_on_slider_changed)

	# CONNECT ON-SCREEN TOUCH BUTTONS
	var btn_left = $CanvasLayer/BottomLeftControls/HBox/BtnLeft
	var btn_right = $CanvasLayer/BottomLeftControls/HBox/BtnRight
	var btn_action = $CanvasLayer/BottomRightControls/BtnAction

	# Handle hold & release for mobile movement buttons
	btn_left.button_down.connect(func(): move_direction = -1.0; feedback_label.text = "Left Touch Button Active!")
	btn_left.button_up.connect(func(): if move_direction < 0: move_direction = 0.0; feedback_label.text = "")

	btn_right.button_down.connect(func(): move_direction = 1.0; feedback_label.text = "Right Touch Button Active!")
	btn_right.button_up.connect(func(): if move_direction > 0: move_direction = 0.0; feedback_label.text = "")

	btn_action.pressed.connect(_on_action_pressed)

func _on_action_pressed() -> void:
	# Action triggers jump and increments score
	player.velocity.y = -350.0
	score += 100
	score_label.text = "Score: %d (Top-Right)" % score
	feedback_label.text = "Action Button Clicked! Player Jumped (+100 Score)."

func _on_slider_changed(value: float) -> void:
	world_camera.position.x = value

func _physics_process(delta: float) -> void:
	# Combine keyboard with mobile touch buttons
	var dir = move_direction
	if dir == 0.0:
		dir = Input.get_axis("ui_left", "ui_right")

	player.velocity.x = dir * 280.0
	
	# Gravity on player
	if not player.is_on_floor():
		player.velocity.y += 980.0 * delta
	
	player.move_and_slide()

	# Keep camera following or sync with slider
	if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_RIGHT):
		world_camera.position.x = player.position.x
		pan_slider.value = world_camera.position.x
