extends Node2D

const GEM_SCENE = preload("res://collectible_node.tscn")

@onready var container: Node2D = $GemContainer
@onready var stats_label: Label = $UILayer/Panel/VBox/StatsLabel
@onready var explanation_label: Label = $UILayer/Panel/VBox/ExplanationLabel

var orphan_storage: Array[Node] = [] # Holds references to removed nodes that were never freed

func _ready() -> void:
	$UILayer/Panel/VBox/BtnSpawnBatch.pressed.connect(spawn_batch)
	$UILayer/Panel/VBox/BtnSafeDelete.pressed.connect(safe_delete_all)
	$UILayer/Panel/VBox/BtnMakeOrphans.pressed.connect(create_orphan_leak)
	$UILayer/Panel/VBox/BtnCleanOrphans.pressed.connect(cleanup_orphans)

func _process(_delta: float) -> void:
	# Monitor Godot's live engine memory counts
	var live_nodes = Performance.get_monitor(Performance.OBJECT_NODE_COUNT)
	var orphan_nodes = Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT)
	
	stats_label.text = "Engine Total Nodes: %d\nActive in Tree: %d\nOrphan Nodes in RAM: %d" % [
		live_nodes,
		container.get_child_count(),
		orphan_nodes
	]

func spawn_batch() -> void:
	for i in range(6):
		var gem = GEM_SCENE.instantiate()
		gem.position = Vector2(400.0 + (i * 90.0), 300.0 + (sin(i) * 50.0))
		container.add_child(gem)
	explanation_label.text = "Spawned 6 nodes into the Scene Tree."

func safe_delete_all() -> void:
	# PROPER DESTRUCTION: queue_free() flags for cleanup at end of frame
	var count = container.get_child_count()
	for gem in container.get_children():
		gem.queue_free()
	explanation_label.text = "Properly freed %d nodes with queue_free(). RAM is clean!" % count

func create_orphan_leak() -> void:
	# THE ORPHAN NODE TRAP:
	# Calling remove_child() removes the node from screen, BUT DOES NOT FREE IT FROM MEMORY!
	# The object still sits in RAM, causing a memory leak that will crash mobile devices.
	var count = container.get_child_count()
	if count == 0:
		explanation_label.text = "Spawn some nodes first before creating orphans!"
		return

	for gem in container.get_children():
		container.remove_child(gem)
		orphan_storage.append(gem) # Kept in memory without a tree parent!
	explanation_label.text = "DANGER: Removed %d nodes without queue_free()! Notice the 'Orphan Nodes in RAM' count jumped up!" % count

func cleanup_orphans() -> void:
	var count = orphan_storage.size()
	for orphan in orphan_storage:
		if is_instance_valid(orphan):
			orphan.queue_free()
	orphan_storage.clear()
	explanation_label.text = "Cleaned up %d orphan nodes from RAM using queue_free()." % count
