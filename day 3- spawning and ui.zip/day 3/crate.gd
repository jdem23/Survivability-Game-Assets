extends Area2D

# A reusable object (Scene as Prefab)
# Can be a puzzle block, chest, crate, bullet, or collectible

@export var item_color: Color = Color(0.9, 0.65, 0.2, 1)

func _ready() -> void:
	$VisualBox.color = item_color
