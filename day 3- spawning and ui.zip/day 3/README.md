# Godot 4 Day 3: Architecture, Instancing & Mobile UI

This project contains four interactive scenes demonstrating universal engine architecture concepts:

1. **`day3_seg1_instancing.tscn` (Scenes as Prefabs & Dynamic Instancing)**:
   - Explains the 3-Step Pipeline: `preload()` -> `instantiate()` -> `add_child()`.
   - Contrasts hand-placing 50 objects in the editor vs generating a 5x8 grid dynamically in code.
   - Click/tap anywhere to spawn standalone `crate.tscn` prefabs.

2. **`day3_seg2_lifecycle_memory.tscn` (Node Lifecycles & Memory Management)**:
   - Demonstrates the Node Lifecycle: `_ready()` (born), `_process()` (living), and `queue_free()` (dying).
   - Live performance monitors: Active Nodes vs Orphan Nodes in RAM.
   - Shows the dangerous trap of calling `remove_child()` without `queue_free()`, leaking memory on mobile.

3. **`day3_seg3_canvas_anchors.tscn` (CanvasLayer & Mobile Screen Anchors)**:
   - Separates 2D game world coordinates from screen glass rendering using `CanvasLayer`.
   - Anchors UI controls to screen corners (Top-Left, Top-Right, Bottom-Left, Bottom-Right).
   - Camera pan slider proves world objects move while CanvasLayer UI remains pinned to the glass.

4. **`day3_seg4_signals_hud.tscn` (The Observer Pattern & Heads-Up Display)**:
   - The team lab win state: Decoupled communication using Godot signals.
   - Collectible coins emit custom signals (`coin_collected.emit(points)`).
   - CanvasLayer HUD catches the signal and converts `str(score)` to update `Label.text`.

### How to Run:
1. Extract and import `project.godot` into Godot 4.x.
2. Press **F5** to start from the Title Menu.
3. Use the `<- Back to Title Menu` button in any scene to return to the menu at any time.
